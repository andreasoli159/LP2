﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMS = new System.Windows.Forms.TextBox();
            this.txtDEE = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSM = new System.Windows.Forms.Label();
            this.lblDEE = new System.Windows.Forms.Label();
            this.btnIM = new System.Windows.Forms.Button();
            this.btnIMPP = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(271, 46);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 0;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(271, 89);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(322, 20);
            this.txtNome.TabIndex = 1;
            // 
            // txtMS
            // 
            this.txtMS.Location = new System.Drawing.Point(271, 128);
            this.txtMS.Name = "txtMS";
            this.txtMS.Size = new System.Drawing.Size(138, 20);
            this.txtMS.TabIndex = 2;
            // 
            // txtDEE
            // 
            this.txtDEE.Location = new System.Drawing.Point(271, 173);
            this.txtDEE.Name = "txtDEE";
            this.txtDEE.Size = new System.Drawing.Size(138, 20);
            this.txtDEE.TabIndex = 3;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(87, 47);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(61, 16);
            this.lblMatricula.TabIndex = 4;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(87, 90);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(44, 16);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome";
            // 
            // lblSM
            // 
            this.lblSM.AutoSize = true;
            this.lblSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSM.Location = new System.Drawing.Point(87, 129);
            this.lblSM.Name = "lblSM";
            this.lblSM.Size = new System.Drawing.Size(97, 16);
            this.lblSM.TabIndex = 6;
            this.lblSM.Text = "Salário Mensal";
            // 
            // lblDEE
            // 
            this.lblDEE.AutoSize = true;
            this.lblDEE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDEE.Location = new System.Drawing.Point(87, 174);
            this.lblDEE.Name = "lblDEE";
            this.lblDEE.Size = new System.Drawing.Size(162, 16);
            this.lblDEE.TabIndex = 7;
            this.lblDEE.Text = "Data Entrada na Empresa";
            // 
            // btnIM
            // 
            this.btnIM.Location = new System.Drawing.Point(90, 266);
            this.btnIM.Name = "btnIM";
            this.btnIM.Size = new System.Drawing.Size(127, 51);
            this.btnIM.TabIndex = 8;
            this.btnIM.Text = "Instanciar Mensalista";
            this.btnIM.UseVisualStyleBackColor = true;
            this.btnIM.Click += new System.EventHandler(this.btnIM_Click);
            // 
            // btnIMPP
            // 
            this.btnIMPP.Location = new System.Drawing.Point(316, 266);
            this.btnIMPP.Name = "btnIMPP";
            this.btnIMPP.Size = new System.Drawing.Size(164, 51);
            this.btnIMPP.TabIndex = 9;
            this.btnIMPP.Text = "Instanciar Mensalista passando parâmetro";
            this.btnIMPP.UseVisualStyleBackColor = true;
            this.btnIMPP.Click += new System.EventHandler(this.btnIMPP_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnIMPP);
            this.Controls.Add(this.btnIM);
            this.Controls.Add(this.lblDEE);
            this.Controls.Add(this.lblSM);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtDEE);
            this.Controls.Add(this.txtMS);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMS;
        private System.Windows.Forms.TextBox txtDEE;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSM;
        private System.Windows.Forms.Label lblDEE;
        private System.Windows.Forms.Button btnIM;
        private System.Windows.Forms.Button btnIMPP;
    }
}