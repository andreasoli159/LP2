﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form1>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["Form1"].BringToFront();
            }
            else
            {
                Form1 obj2 = new Form1();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Minimized;
                obj2.Show();
            }
        }
    }
}
