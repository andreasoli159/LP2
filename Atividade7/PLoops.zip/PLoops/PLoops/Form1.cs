﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exerciciosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void btnContarEspacos_Click(object sender, EventArgs e)
        {
            string frase = richTextBoxFrase.Text;
            int contadorEspacos = 0;
            for(int i = 0; i < frase.Length; i++)
            {
                if (frase[i] ==' ')
                {
                    contadorEspacos++;
                }
            }
            richTextBoxFrase.Text = $"Número de espaços:{contadorEspacos}";
        }

        private void btnContarR_Click(object sender, EventArgs e)
        {
            string frase =richTextBoxFrase.Text.ToUpper();
            int contadorR = 0;
            int index = 0;
            while(index < frase.Length)
            {
                if (frase[index] == 'R')
                {
                    contadorR++;
                    {
                        index++;
                    }
                    richTextBoxFrase.Text = $"Número de letras 'R':{contadorR}";
                }
            }
        }

        private void btnContarPares_Click(object sender, EventArgs e)
        {
            string frase = richTextBoxFrase.Text.ToLower().Replace("", "");
            int contadorPares = 0;
            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == frase[i + 1])
                {

                    contadorPares++;
                }
            }
            richTextBoxFrase.Text = $"Número de pares de letras repetidas:{contadorPares}";



        }
    }
}
