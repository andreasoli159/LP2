﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
            
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(ladoA < (ladoB+ladoC) && ladoA>(Math.Abs(ladoB-ladoC)) && 
               ladoB < (ladoA+ladoC) && (ladoB>(Math.Abs(ladoA-ladoC))) &&
               ladoC < (ladoA+ladoB) && (ladoC> (Math.Abs(ladoA-ladoB))))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                    MessageBox.Show("Triangulo Equilátero");
                else
                if (ladoA == ladoB || ladoB == ladoC || ladoA == ladoC)
                    MessageBox.Show("Triangulo Isóceles");
                else
                    MessageBox.Show("Triangulo Escaleno");
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txta.Text = "";
            txtb.Clear();
            txtc.Clear();

        }

        private void txta_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtb_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txta_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(txta.Text, out ladoA)) 
            {
                MessageBox.Show("somente numeros!");
                txta.Clear();
                txta.Focus();
            }
        }

        private void txtb_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtb.Text, out ladoB))
            {
                MessageBox.Show("somente numeros!");
                txtb.Clear();
                txtb.Focus();
            }
        }

        private void txtc_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtc.Text, out ladoC))
            {
                MessageBox. Show("somente numeros!");
                txtc.Clear();
                txtc.Focus();
            }
        }
    }
}
